package com.aipro.select

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Intent.ACTION_SEND == intent?.action) { handleShare(intent); return }
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        val pad = (24 * resources.displayMetrics.density).toInt()
        root.setPadding(pad, pad * 2, pad, pad)
        val title = TextView(this)
        title.text = "AI Pro"
        title.textSize = 30f
        title.gravity = Gravity.CENTER
        root.addView(title)
        status = TextView(this)
        status.textSize = 16f
        status.gravity = Gravity.CENTER
        status.setPadding(0, pad, 0, pad)
        root.addView(status)
        val enable = Button(this)
        enable.text = "Enable AI Pro (step 1 of 1)"
        enable.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        root.addView(enable)
        val how = TextView(this)
        how.text = "\nHow to use:\n1. Tap the button above and switch AI Pro ON.\n2. A dark bubble appears on the edge of your screen.\n3. Tap the bubble, drag a box over anything on screen.\n4. Get text, translate, search, or make a calendar event.\n\nTip: you can also Share any image to AI Pro."
        how.textSize = 15f
        how.setPadding(0, pad, 0, 0)
        root.addView(how)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) {
            val enabled = isServiceEnabled()
            status.text = if (enabled) "Status: ON - the bubble is on your screen edge." else "Status: OFF - accessibility not enabled yet."
        }
    }

    private fun isServiceEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/.CaptureService") || s.contains("$packageName/com.aipro.select.CaptureService")
    }

    private fun handleShare(intent: Intent) {
        val uri = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        val bmp = uri?.let { contentResolver.openInputStream(it)?.use { s -> BitmapFactory.decodeStream(s) } }
        if (bmp != null) {
            Shared.shot = bmp
            startActivity(Intent(this, SelectActivity::class.java))
        }
        finish()
    }
}
