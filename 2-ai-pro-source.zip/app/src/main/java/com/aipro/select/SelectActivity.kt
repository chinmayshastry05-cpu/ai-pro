package com.aipro.select

import android.app.Activity
import android.app.SearchManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.provider.CalendarContract
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.google.mlkit.nl.entityextraction.*
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.max
import kotlin.math.min

class SelectActivity : Activity() {

    private var bmp: Bitmap? = null
    private lateinit var panel: LinearLayout
    private lateinit var resultText: TextView
    private lateinit var selView: SelectionView
    private var currentText = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = Shared.shot
        if (b == null) { finish(); return }
        bmp = b
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        selView = SelectionView(this, b) { crop -> runOcr(crop) }
        root.addView(selView, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        buildPanel()
        root.addView(panel)
        setContentView(root)
    }

    private fun buildPanel() {
        val d = resources.displayMetrics.density
        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setBackgroundColor(Color.parseColor("#F016161C"))
        val pad = (14 * d).toInt()
        panel.setPadding(pad, pad, pad, pad)
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        panel.layoutParams = lp
        panel.visibility = View.GONE

        resultText = TextView(this)
        resultText.textSize = 16f
        resultText.setTextColor(Color.WHITE)
        resultText.setTextIsSelectable(true)
        val scroll = ScrollView(this)
        scroll.addView(resultText)
        val sl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        sl.height = (180 * d).toInt()
        panel.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (180 * d).toInt()))

        val row1 = LinearLayout(this)
        val row2 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        row2.orientation = LinearLayout.HORIZONTAL
        fun btn(t: String, parent: LinearLayout, f: () -> Unit) {
            val b = Button(this)
            b.text = t
            b.setOnClickListener { f() }
            val bl = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            parent.addView(b, bl)
        }
        btn("Copy", row1) { copyText() }
        btn("Share", row1) { shareText() }
        btn("Search", row1) { searchText() }
        btn("Translate", row2) { translateText() }
        btn("Add event", row2) { addEvent() }
        btn("Close", row2) { finish() }
        panel.addView(row1)
        panel.addView(row2)
    }

    private fun runOcr(crop: Bitmap) {
        val client = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        client.process(InputImage.fromBitmap(crop, 0))
            .addOnSuccessListener { r ->
                currentText = r.text.trim()
                if (currentText.isEmpty()) currentText = "(no text found - try a bigger box)"
                selView.visibility = View.GONE
                panel.visibility = View.VISIBLE
                resultText.text = currentText
            }
            .addOnFailureListener {
                Toast.makeText(this, "Read failed, try again", Toast.LENGTH_SHORT).show()
                finish()
            }
    }

    private fun copyText() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("AI Pro", resultText.text.toString()))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }

    private fun shareText() {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, resultText.text.toString())
        startActivity(Intent.createChooser(i, "Share"))
    }

    private fun searchText() {
        try {
            val i = Intent(Intent.ACTION_WEB_SEARCH)
            i.putExtra(SearchManager.QUERY, resultText.text.toString())
            startActivity(i)
        } catch (e: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(resultText.text.toString()))))
        }
    }

    private fun translateText() {
        val src = resultText.text.toString()
        if (src.isBlank()) return
        Toast.makeText(this, "Translating (first time downloads a small model)...", Toast.LENGTH_SHORT).show()
        LanguageIdentification.getClient().identifyLanguage(src).addOnSuccessListener { lang ->
            val fromEn = lang == "en"
            val opts = TranslatorOptions.Builder()
                .setSourceLanguage(if (fromEn) TranslateLanguage.ENGLISH else TranslateLanguage.HINDI)
                .setTargetLanguage(if (fromEn) TranslateLanguage.HINDI else TranslateLanguage.ENGLISH)
                .build()
            val tr = Translation.getClient(opts)
            tr.downloadModelIfNeeded().addOnSuccessListener {
                tr.translate(src).addOnSuccessListener { out -> resultText.text = out; currentText = out }
                    .addOnFailureListener { Toast.makeText(this, "Translate failed", Toast.LENGTH_SHORT).show() }
            }.addOnFailureListener { Toast.makeText(this, "Model download failed - check internet", Toast.LENGTH_SHORT).show() }
        }.addOnFailureListener { Toast.makeText(this, "Language detect failed", Toast.LENGTH_SHORT).show() }
    }

    private fun addEvent() {
        val text = resultText.text.toString()
        val ex = EntityExtraction.getClient(EntityExtractorOptions.Builder(EntityExtractorOptions.ENGLISH).build())
        fun openCal(startMillis: Long?) {
            val i = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
            i.putExtra(CalendarContract.Events.TITLE, text.lineSequence().firstOrNull()?.take(60) ?: "AI Pro event")
            i.putExtra(CalendarContract.Events.DESCRIPTION, text)
            if (startMillis != null) {
                i.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMillis)
                i.putExtra(CalendarContract.EXTRA_EVENT_END_TIME, startMillis + 60 * 60 * 1000)
            }
            try { startActivity(i) } catch (e: Exception) { Toast.makeText(this, "No calendar app found", Toast.LENGTH_SHORT).show() }
        }
        ex.downloadModelIfNeeded().addOnSuccessListener {
            ex.annotate(EntityExtractionParams.Builder(text).build()).addOnSuccessListener { anns ->
                var ts: Long? = null
                for (a in anns) for (e in a.entities) if (e is DateTimeEntity) { ts = e.timestampMillis; break }
                openCal(ts)
            }.addOnFailureListener { openCal(null) }
        }.addOnFailureListener { openCal(null) }
    }
}

class SelectionView(context: Context, private val bmp: Bitmap, private val onPicked: (Bitmap) -> Unit) : View(context) {

    private var scale = 1f
    private var ox = 0f
    private var oy = 0f
    private var sx = -1f; private var sy = -1f; private var ex = -1f; private var ey = -1f
    private val dash = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 4f
        pathEffect = DashPathEffect(floatArrayOf(16f, 12f), 0f)
    }
    private val dim = Paint().apply { color = 0xA0000000.toInt() }
    private var busy = false

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        scale = min(w.toFloat() / bmp.width, h.toFloat() / bmp.height)
        ox = (w - bmp.width * scale) / 2f
        oy = (h - bmp.height * scale) / 2f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val dst = RectF(ox, oy, ox + bmp.width * scale, oy + bmp.height * scale)
        canvas.drawBitmap(bmp, null, dst, null)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
        if (sx >= 0 && ex >= 0) {
            val r = normRect()
            canvas.save()
            canvas.clipRect(r)
            canvas.drawBitmap(bmp, null, dst, null)
            canvas.restore()
            canvas.drawRect(r, dash)
        }
    }

    private fun normRect(): RectF {
        val l = max(ox, min(sx, ex)); val t = max(oy, min(sy, ey))
        val r = min(ox + bmp.width * scale, max(sx, ex)); val b = min(oy + bmp.height * scale, max(sy, ey))
        return RectF(l, t, r, b)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (busy) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { sx = e.x; sy = e.y; ex = e.x; ey = e.y; invalidate() }
            MotionEvent.ACTION_MOVE -> { ex = e.x; ey = e.y; invalidate() }
            MotionEvent.ACTION_UP -> {
                ex = e.x; ey = e.y
                val r = normRect()
                if (r.width() > 30 && r.height() > 30) {
                    busy = true
                    val l = ((r.left - ox) / scale).toInt().coerceIn(0, bmp.width - 1)
                    val t = ((r.top - oy) / scale).toInt().coerceIn(0, bmp.height - 1)
                    val rr = ((r.right - ox) / scale).toInt().coerceIn(l + 1, bmp.width)
                    val bb = ((r.bottom - oy) / scale).toInt().coerceIn(t + 1, bmp.height)
                    onPicked(Bitmap.createBitmap(bmp, l, t, rr - l, bb - t))
                } else { sx = -1f; ex = -1f; invalidate() }
            }
        }
        return true
    }
}
