package com.aipro.select

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.ImageView
import android.widget.Toast
import kotlin.math.abs

class CaptureService : AccessibilityService() {

    private var wm: WindowManager? = null
    private var bubble: View? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun showBubble() {
        if (bubble != null) return
        val iv = ImageView(this)
        iv.setImageResource(R.drawable.bubble)
        val size = (56 * resources.displayMetrics.density).toInt()
        val p = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        var downX = 0f; var downY = 0f; var moved = false
        iv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (abs(dx) + abs(dy) > 24) moved = true
                    if (moved) {
                        p.x = (p.x - dx.toInt()).coerceAtLeast(0)
                        p.y = (p.y + dy.toInt())
                        downX = e.rawX; downY = e.rawY
                        try { wm?.updateViewLayout(v, p) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) captureNow(); true }
                else -> false
            }
        }
        wm?.addView(iv, p)
        bubble = iv
    }

    private fun captureNow() {
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(screenshot: ScreenshotResult) {
                val hw = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace)
                screenshot.hardwareBuffer.close()
                val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                if (bmp != null) {
                    Shared.shot = bmp
                    val i = Intent(this@CaptureService, SelectActivity::class.java)
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                } else {
                    Toast.makeText(this@CaptureService, "Capture failed", Toast.LENGTH_SHORT).show()
                }
            }
            override fun onFailure(errorCode: Int) {
                Toast.makeText(this@CaptureService, "Capture blocked ($errorCode)", Toast.LENGTH_SHORT).show()
            }
        })
    }

    override fun onDestroy() {
        bubble?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }
}
