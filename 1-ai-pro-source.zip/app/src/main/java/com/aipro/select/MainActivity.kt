package com.aipro.select

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Intent.ACTION_SEND == intent?.action) { handleShare(intent); return }
        val d = resources.displayMetrics.density
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setBackgroundColor(Color.parseColor("#0B0B0E"))
        val pad = (24 * d).toInt()
        root.setPadding(pad, pad * 2, pad, pad)

        val title = ShimmerTextView(this)
        title.text = "AI PRO"
        title.textSize = 34f
        title.gravity = Gravity.CENTER
        title.setTypeface(null, android.graphics.Typeface.BOLD)
        title.letterSpacing = 0.2f
        root.addView(title)

        status = TextView(this)
        status.textSize = 16f
        status.gravity = Gravity.CENTER
        status.setTextColor(Color.WHITE)
        status.setPadding(0, pad, 0, pad)
        root.addView(status)

        val enable = Button(this)
        enable.text = "Enable AI Pro"
        enable.setTextColor(Color.parseColor("#F5A623"))
        enable.setBackgroundResource(R.drawable.btn_gold)
        enable.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        root.addView(enable)

        val how = TextView(this)
        how.text = """
            
Ways to start a capture:
- Edge panel: Settings > Display > Edge panels > turn ON. Add the Tasks or Apps panel and pin "Capture now" (long-press the AI Pro icon in Apps panel, or pin the shortcut).
- Side button hold: get Samsung's free "RegiStar" app (Galaxy Store) > Side-key press and hold action > open AI Pro Capture. Or set AI Pro as your default assistant: Settings > Apps > Default apps > Digital assistant app, then swipe up from a bottom corner (gesture nav) or hold Home.
- Quick Settings: edit your quick panel and add the "AI Pro" tile.
- Home screen: long-press the AI Pro icon > "Capture now".

Then: drag a box over anything on screen. Copy, translate, search or make a calendar event from what it reads.
""".trimIndent()
        how.textSize = 15f
        how.setTextColor(Color.parseColor("#DDDDDD"))
        how.setPadding(0, pad, 0, 0)
        root.addView(how)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) {
            status.text = if (isServiceEnabled()) "Status: ON - ready to capture." else "Status: OFF - tap Enable AI Pro and switch it on."
        }
    }

    private fun isServiceEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/.CaptureService") || s.contains("$packageName/com.aipro.select.CaptureService")
    }

    private fun handleShare(intent: Intent) {
        val uri = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        val bmp = uri?.let { contentResolver.openInputStream(it)?.use { s -> BitmapFactory.decodeStream(s) } }
        if (bmp != null) {
            Shared.shot = bmp
            startActivity(Intent(this, SelectActivity::class.java))
        }
        finish()
    }
}
