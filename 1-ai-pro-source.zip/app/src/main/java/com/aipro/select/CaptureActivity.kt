package com.aipro.select

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

class CaptureActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val svc = CaptureService.instance
        if (svc != null) {
            svc.captureNow()
        } else {
            Toast.makeText(this, "Turn on AI Pro in Accessibility first", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java))
        }
        finish()
    }
}
