package com.aipro.select

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class CaptureService : AccessibilityService() {

    companion object { @Volatile var instance: CaptureService? = null }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onServiceConnected() { instance = this }

    fun captureNow() {
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(screenshot: ScreenshotResult) {
                val hw = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace)
                screenshot.hardwareBuffer.close()
                val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                if (bmp != null) {
                    Shared.shot = bmp
                    val i = Intent(this@CaptureService, SelectActivity::class.java)
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                } else {
                    Toast.makeText(this@CaptureService, "Capture failed", Toast.LENGTH_SHORT).show()
                }
            }
            override fun onFailure(errorCode: Int) {
                Toast.makeText(this@CaptureService, "Capture blocked ($errorCode)", Toast.LENGTH_SHORT).show()
            }
        })
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }
}
